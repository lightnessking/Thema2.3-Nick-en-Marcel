
package Hex;

public class HexCalculator { 
    
    public static void main(String[] args) 
    {
        long decimal = 3405691582L; 

        System.out.println(Long.toHexString(decimal));
    }
}


