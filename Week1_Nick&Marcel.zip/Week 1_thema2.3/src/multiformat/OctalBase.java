package multiformat;

/**
 * Decimal numbering base
 */

public class OctalBase
extends Base {
  public OctalBase() {
    super("oct",8,"01234567");
  }
}