package exceptions;

public class NumberBaseException extends Exception {
    public NumberBaseException(String message)
    {
        super(message);
    }
}